# read the Inputs

# solve the problem

# print the answer

# be mindful of the running time: O(n^3) is not fast enough
