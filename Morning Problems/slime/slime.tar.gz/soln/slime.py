# read the input

# solve the problem

# print the answer

# ????

# profit!
