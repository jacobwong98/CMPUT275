# a queue may be helpful, but is not necessary
from collections import deque

# read the Inputs

# solve the problem

# print the answer

# Be mindful of running time, deleting an item in the middle of a list is
# too expensive! The intended running time is O(n*q).

# If the test center is taking forever, press ctrl-c from the terminal
# where you launched the test center to quit it prematurely.
