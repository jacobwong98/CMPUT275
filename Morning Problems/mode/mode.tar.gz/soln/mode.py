words = input().split()

# words is now a list of all strings in the input

# finish the problem!
