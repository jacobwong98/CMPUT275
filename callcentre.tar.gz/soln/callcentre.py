# read the first line

# read the calls

# read and process each query
