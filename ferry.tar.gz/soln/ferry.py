# read the input

# solve the problem

# print the answer!

# Hint: consider having a variable tracking the current "time" and
# a variable tracking which side of the shore the ferry lies on
