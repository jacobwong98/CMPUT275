num_matches = int(input())

for i in range(num_matches):
    rounds = input().split()
    # now rounds is a list of the rounds in this match
    # example: if the line of input was "RR RP SR" then
    # rounds == ["RR", "RP", "SR"]
    # now do the rest!

# print here whoever is the overall winner of all the matches and
# how many matches the winner won
